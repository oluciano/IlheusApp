enum StatusFatura {
  rascunho,
  publicado,
}
