enum StatusDebito {
  aberto,
  quitado,
}
