enum ModeloJuros {
  igualitario,
  proporcionalDias,
}
