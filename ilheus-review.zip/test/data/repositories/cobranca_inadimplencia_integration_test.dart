import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:sqflite/sqflite.dart';

import 'package:ilheus_app/features/agua/data/repositories/cobranca_repository_impl.dart'
    as repo_impl;
import 'package:ilheus_app/features/agua/domain/models/cobranca.dart';
import 'package:ilheus_app/features/agua/domain/models/status_cobranca.dart';

// Mock database for testing
class _MockDatabase extends Mock implements Database {}

void main() {
  late _MockDatabase db;
  late repo_impl.CobrancaRepositoryImpl repository;

  setUp(() {
    db = _MockDatabase();
    final dataSource = _TestCobrancaDataSource(db);
    repository = repo_impl.CobrancaRepositoryImpl(dataSource);
  });

  group('marcarInadimplentesPorVencimento - comportamento esperado', () {
    test('executa rawUpdate para marcar cobranças inadimplentes', () async {
      // Arrange
      when(() => db.rawUpdate(any(), any()))
          .thenAnswer((_) async => 1);

      // Act
      await repository.marcarInadimplentesPorVencimento('2026-04');

      // Assert: Verificar que rawUpdate foi chamado
      verify(() => db.rawUpdate(any(), any())).called(1);
    });

    test('calcula mesAnterior = 2026-03 quando mesAtual = 2026-04', () async {
      // Arrange
      when(() => db.rawUpdate(any(), any()))
          .thenAnswer((_) async => 0);

      // Act
      await repository.marcarInadimplentesPorVencimento('2026-04');

      // Assert: Verificar parametros da chamada
      final callArgs = verify(() => db.rawUpdate(any(), captureAny()))
          .captured
          .first as List<dynamic>;

      expect(callArgs, contains('2026-03')); // mesAnterior
      expect(callArgs, contains(StatusCobranca.inadimplente.name));
      expect(callArgs, contains(StatusCobranca.pendente.name));
    });

    test('calcula mesAnterior = 2025-12 quando mesAtual = 2026-01', () async {
      // Arrange
      when(() => db.rawUpdate(any(), any()))
          .thenAnswer((_) async => 0);

      // Act: Janeiro retorna dezembro do ano anterior
      await repository.marcarInadimplentesPorVencimento('2026-01');

      // Assert
      final callArgs = verify(() => db.rawUpdate(any(), captureAny()))
          .captured
          .first as List<dynamic>;

      expect(callArgs, contains('2025-12'));
    });
  });
}

/// Test data source wrapper
class _TestCobrancaDataSource extends repo_impl.CobrancaDataSource {
  _TestCobrancaDataSource(_MockDatabase db) : super(db as Database);
}
